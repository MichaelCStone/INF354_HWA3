export class User {
    emailaddress! : string;
    password!: string;
}