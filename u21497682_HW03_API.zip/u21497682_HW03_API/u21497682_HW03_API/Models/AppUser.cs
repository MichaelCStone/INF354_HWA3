﻿using Microsoft.AspNetCore.Identity;

namespace Assignment3_Backend.Models
{
    public class AppUser: IdentityUser
    {
    }
}
