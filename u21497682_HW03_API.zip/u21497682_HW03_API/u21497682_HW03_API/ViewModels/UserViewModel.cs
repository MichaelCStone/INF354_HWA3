﻿namespace Assignment3_Backend.ViewModels
{
    public class UserViewModel
    {
        public string emailaddress { get; set; }
        public string password { get; set; }

    }
}
